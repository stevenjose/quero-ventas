<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid float-end">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ms-auto" style="margin-right: 100px">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">INICIO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">SOBRE EL EVENTO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">TEMAS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">PONENTES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">POGRAMACIÓN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">PATROCIANDORES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link form-control btn-navbar" href="#" tabindex="-1" aria-disabled="true">REGISTER</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

