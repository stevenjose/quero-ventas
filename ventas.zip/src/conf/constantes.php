<?php
define('URl_VIEW', './src/view/');