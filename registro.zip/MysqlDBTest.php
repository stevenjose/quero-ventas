<?php


use PHPUnit\Framework\TestCase;

class MysqlDBTest extends TestCase
{

    public function testGetData()
    {

    }
}
