<div class="mt-2">
    <h2 class="p-4 mr-4 mt-1" style="color: #333333">
        <a href="#" class="link-header">Empresa</a> | <a href="https://avemperu.com/es/avem-peru/register" target="_blank" class="link-header"> Persona </a>
    </h2>
    <hr class="hr-header">
</div>