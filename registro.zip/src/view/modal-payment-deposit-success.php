
<div class="modal fade" id="modalPaymentDepositSuccess" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row text-center">
                    <img src="../../asssets/img/avem.png"  id="logo-payment" class="img-fluid" alt="img-logo" style="padding: 80px"/>
                </div>
                <h3 class="text-center">!Gracias!</h3>
                <div class="row mt-4 p-4">
                    <div class="col-12 col-lg-12 col-md-12">
                        <p class="text-center">
                            Gracias hemos recibido, una inscripción, al Congreso Peruano de Avicultura AVEM 2021 nos vemos los días 4,5,6 de Octubre
                            a través de nuestra moderna plataforma digital.
                        </p>
                        <br>
                        <p class="text-center">
                            Estamos felices de que vivas la experiencia AVEM y participes en este evento de alcance internacional que congregara a la
                            comunidad agricola en pleno.
                        </p>
                        <br>
                        <p class="text-center">
                            Pronto nos comunicaremos contigo.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
